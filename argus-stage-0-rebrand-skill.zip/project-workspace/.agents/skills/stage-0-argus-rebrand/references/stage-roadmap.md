# Stage Roadmap

## Phase 0 — Baseline and Safety

1. Confirm clean git status.
2. Read `AGENTS.md`.
3. Read this skill and forbidden changes.
4. Run initial trace scan.

Deliverable: categorized list of current traces.

## Phase 1 — Branding Abstraction

1. Inspect frontend source conventions.
2. Add or extend a central brand constants/config file.
3. Export Argus product name values.

Deliverable: single source of truth for product display name.

## Phase 2 — Frontend Display Rebrand

1. Update browser title and metadata.
2. Update login page.
3. Update navigation/sidebar/header.
4. Update dashboard/chat/knowledge/intent/MCP/trace/settings visible copy.
5. Update empty states, toasts and footer/help/about copy.

Deliverable: frontend displays Argus consistently.

## Phase 3 — Safe Documentation Cleanup

1. Update product-facing README/docs if needed.
2. Preserve operational commands and technical identifiers.
3. Add notes for intentionally preserved identifiers.

Deliverable: docs present Argus without breaking setup.

## Phase 4 — Verification

1. Run trace scan.
2. Run frontend build.
3. Run backend compile.
4. Summarize changed files.
5. Review remaining hits.

Deliverable: final summary with pass/fail/not-run results.

## Later Stages Not Included Here

These are intentionally out of scope for Stage 0:

- Full Java package rename to `com.argus...`.
- Maven coordinate rename.
- Database rename from `ragent` to `argus`.
- Docker Compose / middleware stack rename.
- API path rename.
- New business features.
- Deployment automation.

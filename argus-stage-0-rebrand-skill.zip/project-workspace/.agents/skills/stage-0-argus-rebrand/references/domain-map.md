# Domain Map

This map helps classify `Ragent` / `ragent` / `nageoffer` occurrences during Stage 0.

## Replace Now

Replace these when they are user-visible:

| Area | Examples | Replacement |
| --- | --- | --- |
| Browser title | `Ragent AI` | `Argus AI` |
| Login page | `欢迎使用 Ragent` | `欢迎使用 Argus` |
| Sidebar logo/title | `Ragent` | `Argus` |
| Header title | `Ragent AI` | `Argus AI` |
| Dashboard copy | `Ragent 控制台` | `Argus 管理控制台` |
| Chat welcome text | `我是 Ragent...` | `我是 Argus...` |
| Public product description | `Ragent 是...` | `Argus 是...` |
| Visible footer/about copy | `nageoffer` as product owner/branding | remove or replace with neutral Argus wording |

## Preserve Intentionally

Do not change these in Stage 0:

| Area | Examples | Reason |
| --- | --- | --- |
| Java package | `com.nageoffer.ai.ragent` | Package rename is high-risk and not needed for UI branding |
| Main class | `RagentApplication` | Renaming can break run configs and docs |
| Maven coordinates | `com.nageoffer.ai:ragent` | Artifact migration is a later stage |
| Database name | `ragent` | User explicitly said not to change DB name |
| JDBC URL | `jdbc:postgresql://.../ragent` | Changing requires DB reconfiguration |
| Docker env | `POSTGRES_DB=ragent` | Changing requires middleware reconfiguration |
| Docker compose files | service names, ports, volumes, credentials | User explicitly said not to change middleware params |
| Redis/RocketMQ names | prefixes, topics, consumer groups | Runtime compatibility |
| SQL scripts | schema/init/upgrade files | Startup compatibility |
| API paths | `/api/...`, `/mcp` | Client compatibility |
| Legal notices | LICENSE / required copyright | Legal and attribution requirements |

## Review Carefully

These areas require judgment:

| Area | Guidance |
| --- | --- |
| README | Product packaging can be Argus; setup commands must stay technically correct |
| Docs | User-facing intro docs can be Argus; operational config docs must preserve technical identifiers |
| Screenshots | Do not regenerate binary screenshots unless requested |
| Static assets | Replace text SVG/HTML assets if easy; do not block the stage on binary image edits |
| `package.json` name | Change only if it does not affect build/deploy scripts; keep package manager behavior stable |
| `spring.application.name` | Usually preserve in Stage 0 unless confirmed display-only |
| API docs title | Can change only if not used by deployment/service discovery |

## Search Terms

Scan for:

```text
Ragent
Ragent AI
ragent
RAGENT
nageoffer
拿个 offer
马哥
星球
open8gu
```

Also scan generated build artifacts only if needed. Ignore `node_modules`, `target`, `.git`, `dist`, `build` and lock files unless a hit is directly user-visible.

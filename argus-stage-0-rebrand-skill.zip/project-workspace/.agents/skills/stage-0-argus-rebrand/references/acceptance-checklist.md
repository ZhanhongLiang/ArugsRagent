# Acceptance Checklist

## Branding

- [ ] UI displays **Argus** or **Argus AI**, not `Ragent` / `Ragent AI`.
- [ ] Browser title uses Argus.
- [ ] Login page uses Argus.
- [ ] Sidebar/header product identity uses Argus.
- [ ] Dashboard, chat, knowledge-base, intent, MCP, trace and settings pages do not expose original project branding.
- [ ] User-facing footer/about/help copy does not expose `nageoffer`, `拿个 offer`, training/community copy, or star-begging copy as product identity.

## Brand Abstraction

- [ ] A single brand constants/config file exists or an existing app constants file was reused.
- [ ] New/edited UI code imports the brand constants where practical.
- [ ] No large scatter of duplicate `Argus` literals was introduced without reason.

## Technical Compatibility

- [ ] Database name `ragent` remains unchanged.
- [ ] `POSTGRES_DB=ragent` remains unchanged.
- [ ] JDBC URLs with `/ragent` remain unchanged.
- [ ] Docker Compose files and middleware parameters are unchanged.
- [ ] Java package names remain unchanged.
- [ ] Maven module names remain unchanged.
- [ ] API endpoints remain unchanged.
- [ ] Request/response contracts remain unchanged.
- [ ] Existing local startup process still applies.

## Build / Verification

- [ ] `scripts/grep-teaching-traces.ps1` was run after changes.
- [ ] Frontend build was run or a clear not-run reason was recorded.
- [ ] Backend compile was run or a clear not-run reason was recorded.
- [ ] `scripts/summarize-changed-files.ps1` was run.
- [ ] Final summary lists intentionally preserved technical `ragent` occurrences.

## Code Quality

- [ ] No blind global search-and-replace was used.
- [ ] No new dependency was added for branding only.
- [ ] Changes are small and reviewable.
- [ ] No unrelated refactors were included.
- [ ] No secrets or local config values were modified.

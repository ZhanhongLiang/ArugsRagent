# Forbidden Changes

Stage 0 must not include any of the following changes.

## Runtime / Middleware

- Do not change PostgreSQL database name `ragent`.
- Do not change `POSTGRES_DB=ragent`.
- Do not change PostgreSQL username/password/port/volume.
- Do not change Redis password/port/prefix.
- Do not change RocketMQ nameserver, topic names, consumer groups or compose parameters.
- Do not change RustFS/MinIO access key, secret key, ports, buckets, volumes or service names.
- Do not change Docker Compose networks, service names, container names, ports or volumes.
- Do not change environment variable names or values that affect local startup.

## Backend Identity

- Do not rename Java packages.
- Do not rename `RagentApplication`.
- Do not rename `MCPServerApplication`.
- Do not rename Maven modules.
- Do not change parent/child POM coordinates for branding only.
- Do not rename database tables or columns.
- Do not generate SQL migrations for branding only.
- Do not modify mapper XML for branding only.
- Do not change controller paths.
- Do not change DTO/VO/entity field names.
- Do not change authentication behavior.

## Architecture

- Do not rewrite the RAG pipeline.
- Do not replace retrieval logic.
- Do not change model routing or circuit-breaker behavior.
- Do not change MCP protocol methods.
- Do not introduce a new framework.
- Do not add frontend dependencies for a branding-only change.
- Do not introduce full Spring Security.
- Do not move code across modules.

## Process

- Do not use blind global search-and-replace.
- Do not delete license/copyright files.
- Do not modify secrets.
- Do not include unrelated refactors.
- Do not claim verification passed unless commands were actually run.
- Do not hide remaining `ragent` hits; classify and report them.

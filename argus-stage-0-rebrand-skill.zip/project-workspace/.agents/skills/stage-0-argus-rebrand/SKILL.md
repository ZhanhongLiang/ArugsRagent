# Stage 0 Skill: Argus Rebrand / Teaching-Trace Removal

## Purpose

Use this skill to transform the `nageoffer/ragent` project into a user-facing **Argus** project without breaking local development, database initialization, Docker middleware, API compatibility or backend package stability.

This is a controlled branding stage. It removes visible original-project shadows while preserving technical identifiers that would be expensive or risky to migrate.

## When to Use

Use this skill when the user asks to:

- Rename the project from Ragent to Argus.
- Remove Ragent / Ragent AI / nageoffer traces.
- Make the frontend look like an independent Argus project.
- Prepare a first-stage Codex refactor before deeper feature development.

Do not use this skill for:

- Full Java package migration.
- Database rename.
- Docker Compose rewrite.
- API path redesign.
- Authentication redesign.
- RAG retrieval architecture changes.

## Product Naming

Use these names:

```text
shortName: Argus
fullName: Argus AI
description: 企业级 RAG 智能问答平台
consoleName: Argus 管理控制台
```

## Hard Constraints

You must obey these constraints:

1. No global blind search-and-replace.
2. Do not rename the database `ragent`.
3. Do not change `POSTGRES_DB=ragent`.
4. Do not change JDBC URLs using `/ragent`.
5. Do not modify Docker Compose service names, ports, volumes, credentials, environment variable values or middleware parameters.
6. Do not rename Java packages such as `com.nageoffer.ai.ragent`.
7. Do not rename `RagentApplication` or `MCPServerApplication` in Stage 0.
8. Do not rename Maven modules: `bootstrap`, `framework`, `infra-ai`, `mcp-server`.
9. Do not change API endpoint paths or request/response schemas.
10. Do not remove required license or copyright files.
11. Do not add frontend dependencies for a branding-only change unless the existing project already has an equivalent dependency and the reason is documented.
12. Preserve behavior: this stage changes presentation, not features.

## Design Requirements

### Open/Closed Principle

Add or reuse a branding abstraction instead of scattering literals.

Preferred implementation pattern:

```ts
export const BRAND = {
  shortName: 'Argus',
  fullName: 'Argus AI',
  description: '企业级 RAG 智能问答平台',
  consoleName: 'Argus 管理控制台',
};
```

Use the existing frontend conventions when choosing the file path. Good candidates:

```text
frontend/src/config/brand.ts
frontend/src/constants/brand.ts
frontend/src/lib/brand.ts
```

Then import the brand object into UI components.

### Functional Decoupling

Keep user-facing branding independent from:

- Database names.
- Java package names.
- Maven artifact names.
- Docker service names.
- Redis/RocketMQ prefixes.
- API paths.
- Storage bucket or collection names.

## Execution Procedure

### Step 1: Inspect repository shape

Confirm the repository has the expected layout:

```text
bootstrap/
framework/
infra-ai/
mcp-server/
frontend/
resources/
pom.xml
mvnw / mvnw.cmd
```

If the layout differs, adapt paths but preserve the constraints.

### Step 2: Run initial trace scan

Run:

```powershell
.\scripts\grep-teaching-traces.ps1
```

If the script is not present yet, use the copy under:

```text
.agents/skills/stage-0-argus-rebrand/scripts/grep-teaching-traces.ps1
```

Classify every hit:

- **Replace now**: visible frontend display text or product packaging.
- **Preserve intentionally**: technical identity/configuration.
- **Review**: docs where setup/legal context matters.

### Step 3: Locate frontend brand surfaces

Inspect these likely areas:

```text
frontend/index.html
frontend/package.json
frontend/src/**
frontend/public/**
frontend/vite.config.*
frontend/.env*
```

Look for:

```text
Ragent
Ragent AI
ragent
nageoffer
拿个 offer
马哥
星球
open8gu
```

Do not treat lowercase `ragent` as automatically replaceable. It may be part of API paths, storage keys, docs or config.

### Step 4: Add central brand config

Create or reuse a central brand file following the project's style.

Do not use a new dependency.

Suggested content:

```ts
export const BRAND = {
  shortName: 'Argus',
  fullName: 'Argus AI',
  description: '企业级 RAG 智能问答平台',
  consoleName: 'Argus 管理控制台',
} as const;
```

If the project already has an app constants file, extend it rather than creating a competing pattern.

### Step 5: Replace frontend UI-visible copy

Replace only user-visible branding:

- Browser title.
- Login page title/subtitle.
- Sidebar product name.
- Header product name.
- Dashboard product copy.
- Chat welcome copy.
- Knowledge-base management intro copy.
- Intent/MCP/trace/settings page intro copy.
- Toast/notification product name.
- Empty states and help text.
- Footer/about text.

Use brand constants where practical.

### Step 6: Optional safe docs cleanup

For README or docs:

- Change product packaging from Ragent to Argus when the doc is meant for portfolio/product presentation.
- Keep setup commands technically correct.
- Do not rewrite DB/Docker commands to Argus in this stage.
- If a doc says `POSTGRES_DB=ragent`, keep it.
- If a doc explains original history or legal attribution, do not delete it blindly.

### Step 7: Do not alter backend identity

Avoid changing:

```text
com/nageoffer/ai/ragent
RagentApplication
spring.application.name
pom.xml groupId/artifactId
resources/database
resources/docker
application.yaml datasource URL
Redis prefixes
RocketMQ names
```

If a backend string is genuinely user-facing, such as an API docs title, change it only after confirming it does not affect deployment or client contracts.

### Step 8: Verify

Run checks:

```powershell
.\scripts\grep-teaching-traces.ps1
.\scripts\verify-frontend-build.ps1
.\scripts\verify-backend-build.ps1
.\scripts\summarize-changed-files.ps1
```

If a command fails because the environment is missing Node, JDK, Maven or network access, document that exactly.

### Step 9: Produce final implementation summary

Use this summary shape:

```text
Stage 0 complete: Argus rebrand

User-facing changes:
- ...

Brand abstraction:
- ...

Preserved technical identifiers:
- Database name ragent
- Java package com.nageoffer.ai.ragent
- Docker middleware parameters
- Maven module structure

Verification:
- grep-teaching-traces: ...
- frontend build: ...
- backend compile: ...

Remaining review:
- ...
```

## Acceptance Criteria

See `references/acceptance-checklist.md`.

## Forbidden Changes

See `references/forbidden-changes.md`.

## Domain Map

See `references/domain-map.md`.

## Roadmap

See `references/stage-roadmap.md`.

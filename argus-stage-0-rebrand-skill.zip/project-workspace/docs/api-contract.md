# API Contract

This document records API compatibility rules for Stage 0: Argus Rebrand / Teaching-Trace Removal.

## Stage Intent

Stage 0 is a presentation-layer and documentation rebrand. It must not change the backend API contract.

## Public API Stability Rules

Do not change:

- URL paths.
- HTTP methods.
- Request body fields.
- Response body fields.
- Response wrapper structure.
- Error codes.
- Authentication headers or token format.
- SSE event names and event data schema.
- File upload form field names.
- Knowledge-base IDs, document IDs, chunk IDs or conversation IDs.
- MCP JSON-RPC methods such as `initialize`, `tools/list`, `tools/call`.

## Frontend API Rules

The frontend may change display labels but must keep API clients compatible.

Allowed:

- Button text.
- Page title.
- Sidebar label.
- Login copy.
- Empty state copy.
- Browser title.
- Static product description.

Forbidden:

- Changing endpoint strings.
- Changing axios/fetch base URL behavior.
- Changing authentication storage keys unless purely display related and fully migrated.
- Changing request DTO names just for branding.
- Changing route paths if existing navigation depends on them.

## Backend API Rules

Allowed only when clearly display-only:

- OpenAPI / Knife4j title or description.
- A frontend-facing app-name field if the project already exposes one and no database or client contract changes are needed.

Forbidden:

- Controller path changes.
- DTO/VO field renames.
- Entity field renames.
- Mapper XML changes for branding only.
- SQL migrations for branding only.
- Package/class renames in Stage 0.

## Compatibility Principle

A user should be able to pull the Stage 0 changes, keep the same database, same Docker Compose stack, same Redis/RocketMQ configuration and same API clients, then see the frontend branded as Argus.

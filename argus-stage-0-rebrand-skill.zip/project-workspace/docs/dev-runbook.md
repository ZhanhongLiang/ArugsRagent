# Dev Runbook

This runbook is for applying and verifying Stage 0: Argus Rebrand / Teaching-Trace Removal.

## 1. Prepare

From the repository root:

```powershell
git status --short
```

Start from a clean branch when possible:

```powershell
git checkout -b stage-0-argus-rebrand
```

## 2. Read the Contracts

Read:

```text
AGENTS.md
.agents/skills/stage-0-argus-rebrand/SKILL.md
.agents/skills/stage-0-argus-rebrand/references/forbidden-changes.md
.agents/skills/stage-0-argus-rebrand/references/acceptance-checklist.md
```

## 3. Scan Existing Traces

```powershell
.\scripts\grep-teaching-traces.ps1
```

Classify hits into:

- Must replace: visible UI/product copy.
- Preserve: package names, DB names, Docker params, Maven coordinates, SQL, middleware config.
- Review: README/docs text that may be user-facing but may include legal/attribution/setup context.

## 4. Implement Branding Abstraction

Inspect the frontend structure and add a brand constants file using the existing style, for example:

```text
frontend/src/config/brand.ts
```

Use imports in UI components rather than duplicating `Argus` string literals everywhere.

## 5. Replace UI-visible Copy

Replace display-only references such as:

- Login page title.
- Sidebar logo/title.
- Header title.
- Dashboard title/subtitle.
- Browser title and meta title.
- Empty states.
- Footer/help/about copy.
- Frontend docs surfaced to users.

Do not change runtime identifiers.

## 6. Verify

```powershell
.\scripts\grep-teaching-traces.ps1
.\scripts\verify-frontend-build.ps1
.\scripts\verify-backend-build.ps1
.\scripts\summarize-changed-files.ps1
```

## 7. Final Summary Template

```text
Completed Stage 0: Argus Rebrand

Changed:
- ...

Added:
- Central brand config at ...

Preserved intentionally:
- Database name ragent
- Java package com.nageoffer.ai.ragent
- Docker Compose parameters
- Maven/module layout

Verification:
- Frontend build: pass/fail/not run
- Backend compile: pass/fail/not run
- Trace scan: remaining allowed hits listed

Remaining review:
- ...
```

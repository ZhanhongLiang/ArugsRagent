# Task Board

## Stage 0: Argus Rebrand / Teaching-Trace Removal

Status: Ready for Codex execution.

## Goals

- Present the project as **Argus** in user-facing frontend surfaces.
- Remove visible original teaching-project branding from the UI.
- Add or reuse a centralized frontend branding abstraction.
- Keep backend/database/middleware compatibility stable.

## Non-goals

- Do not rename Java packages.
- Do not rename Maven modules.
- Do not rename database, tables or SQL scripts.
- Do not modify Docker Compose parameters.
- Do not change API endpoints.
- Do not rewrite the RAG/MCP/retrieval architecture.

## Task List

### T0. Baseline scan

- [ ] Run `scripts/grep-teaching-traces.ps1`.
- [ ] Record visible vs technical occurrences.

### T1. Frontend brand abstraction

- [ ] Add a frontend brand constants file following current conventions.
- [ ] Export product short name, full name and description.
- [ ] Replace repeated UI literals with brand constants.

### T2. UI copy replacement

- [ ] Login page.
- [ ] Sidebar/header.
- [ ] Dashboard.
- [ ] Chat page.
- [ ] Knowledge-base management pages.
- [ ] Intent/MCP/trace/settings pages.
- [ ] Empty states, toast messages, footer/help/about text.
- [ ] Browser title and metadata.

### T3. Safe public docs

- [ ] Update root README only if it is used as portfolio/product packaging.
- [ ] Keep setup commands and middleware names unchanged.
- [ ] Preserve required license/copyright notices.

### T4. Verification

- [ ] Run frontend build.
- [ ] Run backend compile.
- [ ] Run trace scan again.
- [ ] Summarize intentionally preserved technical traces.

## Definition of Done

- The UI no longer exposes `Ragent` / `Ragent AI` / `nageoffer` as product branding.
- The UI consistently presents the product as Argus.
- No database name, Docker/middleware parameter, endpoint path or backend package rename occurred.
- Verification results are summarized with command output or honest not-run reasons.
